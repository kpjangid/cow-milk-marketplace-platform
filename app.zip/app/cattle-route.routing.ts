import { Routes, RouterModule } from '@angular/router';
import { FarmerComponent } from './register/farmer/farmer.component';
import { OtpComponent } from './register/otp/otp.component';
import { Component } from '@angular/core';
import { PasscodeComponent } from './register/passcode/passcode.component';
import { HomeComponent } from './home/home.component';
import { CattleComponent } from './home/cattle/cattle.component';
import { EditCattleComponent } from './home/cattle/edit-cattle/edit-cattle.component';
import { SettingComponent } from './home/setting/setting.component';
import { MarketplaceComponent } from './home/marketplace/marketplace.component';
import { WalletComponent } from './home/wallet/wallet.component';
import { TradeComponent } from './home/trade/trade.component';
import { AuthGuardService } from './guards/auth-guard.service';
import { AddCattleComponent } from './home/cattle/add-cattle/add-cattle.component';
import { LoginComponent } from './register/login/login.component';
import { LandingComponent } from './home/landing/landing.component';
import { MarketCattleComponent } from './home/marketplace/market-cattle/market-cattle.component';
import { MarketMilkComponent } from './home/marketplace/market-milk/market-milk.component';
import { RegisterDoctorComponent } from './doctor/register-doctor/register-doctor.component';
import { LoginDoctorComponent } from './doctor/login-doctor/login-doctor.component';
import { OtpDoctorComponent } from './doctor/otp-doctor/otp-doctor.component';
import { DoctorHomeComponent } from './doctor/home-doctor/doctor-home.component';
import { LandingPageComponent } from './doctor/home-doctor/landing-page/landing-page.component';
import { MainComponent } from './main/main.component';
import { UpdateCowComponent } from './doctor/home-doctor/landing-page/update-cow/update-cow.component';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'main',
    pathMatch: 'full'
  }, {
    path: 'home',
    component: HomeComponent,
    canActivate: [AuthGuardService],
    children: [
      {
        path: 'landing',
        component: LandingComponent
      }, {
        path: 'cattle',
        component: CattleComponent
      }, {
        path: 'setting',
        component: SettingComponent
      }, {
        path: 'marketplace',
        component: MarketplaceComponent
      }, {
        path: 'wallet',
        component: WalletComponent
      }, {
        path: 'trade',
        component: TradeComponent
      }
    ]
  }, {
    path: 'register/farmer',
    component: FarmerComponent
  }, {
    path: 'register/login',
    component: LoginComponent
  }, {
    path: 'register/otp',
    component: OtpComponent
  }, {
    path: 'register/passcode',
    component: PasscodeComponent
  }, {
    path: 'add-cattle',
    component: AddCattleComponent,
    canActivate: [AuthGuardService]
  }, {
    path: 'edit-cattle',
    component: EditCattleComponent,
    canActivate: [AuthGuardService]
  }, {
    path: 'cattle-marketplace',
    component: MarketCattleComponent,
    canActivate: [AuthGuardService]
  }, {
    path: 'milk-marketplace',
    component: MarketMilkComponent,
    canActivate: [AuthGuardService]
  }, {
    path: 'doctor/register',
    component: RegisterDoctorComponent
  }, {
    path: 'doctor/login',
    component: LoginDoctorComponent
  }, {
    path: 'doctor/otp',
    component: OtpDoctorComponent
  }, {
    path: 'doctor/home',
    component: DoctorHomeComponent,
    children: [
      {
        path: 'landing',
        component: LandingPageComponent
      }
    ]
  }, {
    path: 'doctor/cow/update/:id',
    component: UpdateCowComponent
  }, {
    path: 'main',
    component: MainComponent
  }, {
    path: '**',
    redirectTo: 'main'
  }
];

export const CattleRouteRoutes = RouterModule.forRoot(routes);
