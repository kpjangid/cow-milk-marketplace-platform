import { Component, OnInit } from '@angular/core';
import { UtilityService } from '../../shared/services/utilityService';

@Component({
  selector: 'app-wallet',
  templateUrl: './wallet.component.html',
  styleUrls: ['./wallet.component.css']
})
export class WalletComponent implements OnInit {

  amountBalance: any = 232;

  constructor(private utilService: UtilityService) { }

  ngOnInit() {
    this.utilService.activateRouter("Wallet");
  }

}
