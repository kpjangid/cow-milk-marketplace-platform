import { Component, OnInit } from '@angular/core';
import { UtilityService } from '../../shared/services/utilityService';

@Component({
  selector: 'app-trade',
  templateUrl: './trade.component.html',
  styleUrls: ['./trade.component.css']
})
export class TradeComponent implements OnInit {

  constructor(private utilService: UtilityService) { }

  ngOnInit() {
    this.utilService.activateRouter("My Trade");
  }

}
