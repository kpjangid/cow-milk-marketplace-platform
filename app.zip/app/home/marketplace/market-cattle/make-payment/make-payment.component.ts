import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { CattleService } from '../../../cattle/cattle.service';
import { FarmerService } from '../../../../register/farmer.service';

export interface CattleData {
  cowId?: string;
  cowName?: string;
  basePrice?: string;
  farmerId?: string;
}

@Component({
  selector: 'app-make-payment',
  templateUrl: './make-payment.component.html',
  styleUrls: ['./make-payment.component.css']
})
export class MakePaymentComponent implements OnInit {

  constructor(private farmerService: FarmerService, private dialogRef: MatDialogRef<MakePaymentComponent>, @Inject(MAT_DIALOG_DATA) private data: CattleData, private cattleService: CattleService) { }

  amount: string;

  ngOnInit() {
    this.amount = this.data.basePrice;
  }

  makePayment() {

    const cowData = {
      cowId: this.data.cowId,
      cowName: this.data.cowName,
      item: "cow",
      amount: this.data.basePrice,
      paymentFrom: this.farmerService.getFarmer().farmerId,
      paymentTo: this.data.farmerId
    };

    this.cattleService.purchaseCattle(cowData).subscribe(
      (response) => {
        console.log("payment done");
        this.dialogRef.close();
      }
    );
  }

  onNoClick() {
    this.dialogRef.close();
  }

}
