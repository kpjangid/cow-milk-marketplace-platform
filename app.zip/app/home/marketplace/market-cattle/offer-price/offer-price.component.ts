import { Component, OnInit, Inject, ViewChild } from '@angular/core';
import { FarmerService } from '../../../../register/farmer.service';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { CattleData } from '../make-payment/make-payment.component';
import { CattleService } from '../../../cattle/cattle.service';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-offer-price',
  templateUrl: './offer-price.component.html',
  styleUrls: ['./offer-price.component.css']
})
export class OfferPriceComponent implements OnInit {

  @ViewChild('offerPriceForm') offerPriceForm: NgForm;

  constructor(private farmerService: FarmerService, private dialogRef: MatDialogRef<OfferPriceComponent>, @Inject(MAT_DIALOG_DATA) private data: CattleData, private cattleService: CattleService) { }

  amount: string;

  ngOnInit() {
    this.amount = this.data.basePrice;
  }

  makeOfferPrice() {

    const cowData = {
      cowId: this.data.cowId,
      cowName: this.data.cowName,
      amount: this.offerPriceForm.value['offerPrice'],
      farmerId: this.farmerService.getFarmer().farmerId
    };

    this.cattleService.bitForCow(cowData);

    this.dialogRef.close();
  }

  onNoClick() {
    this.dialogRef.close();
  }

}
