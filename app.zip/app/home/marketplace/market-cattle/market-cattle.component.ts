import { Component, OnInit } from '@angular/core';
import { MatBottomSheet, MatDialog } from '@angular/material';
import { BreedFilterSheetComponent } from './breedFilterSheet/breedFilterSheet.component';
import { MarketService, FilterData } from '../market.service';
import { TehsilFilterSheetComponent } from './tehsilFilterSheet/tehsilFilterSheet.component';
import { AgeFilterSheetComponent } from './ageFilterSheet/ageFilterSheet.component';
import { MakePaymentComponent } from './make-payment/make-payment.component';
import { OfferPriceComponent } from './offer-price/offer-price.component';

@Component({
  selector: 'app-market-cattle',
  templateUrl: './market-cattle.component.html',
  styleUrls: ['./market-cattle.component.css']
})
export class MarketCattleComponent implements OnInit {

  constructor(private bottomSheet: MatBottomSheet, private marketService: MarketService, private matDialog: MatDialog) { }

  filterData: FilterData = {};

  cowList: any = [{
    cowId: "cow-1",
    cowName: "hera",
    healthStatus: "Green",
    age: "10 Years",
    basePrice : "2000",
    farmerId : "343284728934723894723847238",
    imageData: "https://media.istockphoto.com/photos/side-view-of-holstein-cow-5-years-old-standing-picture-id106531788"
  }, {
    cowId: "cow-2",
    cowName: "durga",
    healthStatus: "Green",
    age: "10 Years",
    basePrice : "4000",
    farmerId : "34328472893472389472384928349324",
    imageData: "https://static.independent.co.uk/s3fs-public/thumbnails/image/2018/02/14/16/berkeley-farm-dairy.jpg?w968h681"
  }];

  ngOnInit() {
    this.marketService.filterObserver.subscribe(
      (response: FilterData) => {

        this.filterData = response;

        console.log(`filter data updated : ${this.filterData}`);

        this.marketService.getAllAuctionCow(this.filterData).subscribe(
          (response) => {
            console.log(`Cow List = ${JSON.stringify(response)}`);
            this.cowList = response;
          }, (error) => {
            console.error(`Cow List Error = ${JSON.stringify(error)}`);
          }
        );

      }
    );
  }

  breadFilter(): void {
    this.bottomSheet.open(BreedFilterSheetComponent);
  }

  tehsilFilter(): void {
    this.bottomSheet.open(TehsilFilterSheetComponent);
  }

  ageFilter(): void {
    this.bottomSheet.open(AgeFilterSheetComponent);
  }

  makePaymentClicked(cowData) {

    const dialogRef = this.matDialog.open(MakePaymentComponent, {
      width: '400px',
      data: {
        cowId: cowData.cowId,
        cowName: cowData.cowName,
        farmerId: cowData.farmerId,
        basePrice: cowData.basePrice
      }
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log("dialog was closed");
    });
  }

  offerNewClicked(cowData) {

    const dialogRef = this.matDialog.open(OfferPriceComponent, {
      width: '400px',
      data: {
        cowId: cowData.cowId,
        cowName: cowData.cowName,
        basePrice: cowData.basePrice
      }
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log("dialog was closed");
    });
  }

}
