import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-landing-new',
  templateUrl: './landing-new.component.html',
  styleUrls: ['./landing-new.component.css']
})
export class LandingNewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
