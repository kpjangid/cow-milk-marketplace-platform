import { Component, OnInit } from '@angular/core';
import { UtilityService } from '../../shared/services/utilityService';

@Component({
  selector: 'app-landing',
  templateUrl: './landing.component.html',
  styleUrls: ['./landing.component.css']
})
export class LandingComponent implements OnInit {

  constructor(private utilService: UtilityService) { }

  ngOnInit() {
    this.utilService.activateRouter("Home");
  }

}
