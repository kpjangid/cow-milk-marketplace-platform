import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { CattleService } from '../cattle.service';

export interface DialogData {
  cattleId?: string;
  cattleName?: string;
}

@Component({
  selector: 'app-delete-cattle',
  templateUrl: './delete-cattle.component.html',
  styleUrls: ['./delete-cattle.component.css']
})

export class DeleteCattleComponent implements OnInit {

  constructor(private dialogRef: MatDialogRef<DeleteCattleComponent>, @Inject(MAT_DIALOG_DATA) private data: DialogData, private cattleService: CattleService) { }

  ngOnInit() {
  }

  onNoClick() {
    this.dialogRef.close();
  }

  deleteCow() {
    this.cattleService.deleteCattle(this.data.cattleId);
    this.dialogRef.close();
  }

}
