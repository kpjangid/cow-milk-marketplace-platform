import { AppService } from "../../shared/services/appService";
import { Observable, Observer } from "rxjs";
import { HttpHeaders } from "@angular/common/http";
import { Injectable } from "@angular/core";

@Injectable({
    providedIn: 'root'
})
export class CattleService {

    constructor(private appService: AppService) { }

    addCattle(cattleData) {
        const context = "/farmer/addCow";
        const headers = new HttpHeaders();
        headers.set("Content-Type", "application/json");
        this.appService.sendRequest('POST', context, cattleData, headers, null, null).subscribe(
            (response) => {
                console.log(`Cow Added : ${response}`);
            }, (error) => {
                console.log(`Error in while adding Cow : ${error}`);
            }
        );
    }

    getCattleList(farmerId) {

        return new Observable((observe: Observer<any>) => {

            const context = "farmer/getAllCow/" + farmerId;

            this.appService.sendRequest('GET', context, null, null, null, null).subscribe(
                (response) => {

                    const tempCattleList = [];
                    response.forEach(element => {
                        const cow = {
                            cowName: element['cowName'],
                            cowAge: element['dob'],
                            healthStatus: element['healthFlag'],
                            imageData: element['pic'],
                            cowId: element['cowId']
                        };
                        tempCattleList.push(cow);
                    });

                    observe.next(tempCattleList);
                }, (error) => {
                    console.log(`Error in while Getting Cow List : ${error}`);
                    observe.error(error);
                }
            );
        });

    }

    sellCow(cowId, sellParam) {

        const context = "farmer/markCowOnSale/" + cowId;

        this.appService.sendRequest('POST', context, sellParam, null, null, null).subscribe(
            (response) => {
                console.log(`Cow Added in Sale : ${JSON.stringify(response)}`);
            }, (error) => {
                console.log(`Error in while Adding Cow in sale : ${error}`);
            }
        );

    }

    bitForCow(cowdata) {
        const context = "/auction/bidForCow";
        const headers = new HttpHeaders();
        headers.set("Content-Type", "application/json");
        this.appService.sendRequest('POST', context, cowdata, headers, null, null).subscribe(
            (response) => {
                console.log(`Bid Added to Cow : ${response}`);
            }, (error) => {
                console.log(`Error in while Bid Added to Cow  : ${error}`);
            }
        );
    }

    updateCattle(cattleData) {
        const context = "/farmer/updateCow";
        const headers = new HttpHeaders();
        headers.set("Content-Type", "application/json");
        this.appService.sendRequest('PUT', context, cattleData, headers, null, null).subscribe(
            (response) => {
                console.log(`Cow Added for Auction: ${response}`);
            }, (error) => {
                console.log(`Error in while adding Auction : ${error}`);
            }
        );
    }

    deleteCattle(identifier) {
        const context = "/farmer/deleteCow/" + identifier;
        this.appService.sendRequest('DELETE', context, null, null, null, null).subscribe(
            (response) => {
                console.log(`Cow deleted: ${response}`);
            }, (error) => {
                console.log(`Error in while deleting Cow : ${error}`);
            }
        );
    }

    getCowListForAuction(filterData) {

        return new Observable((observe: Observer<any>) => {
            const context = "/auction/searchCow";
            const headers = new HttpHeaders();
            headers.set("Content-Type", "application/json");
            this.appService.sendRequest('POST', context, filterData, headers, null, null).subscribe(
                (response) => {
                    console.log(`Cow Available in Auction: ${JSON.stringify(response)}`);
                    observe.next(response);
                }, (error) => {
                    console.log(`Error in while Getting Auction : ${error}`);
                    observe.error(error);
                }
            );

        });

    }

    sellMilk(milkData) {
        const context = "/farmer/auctionMilk";
        const headers = new HttpHeaders();
        headers.set("Content-Type", "application/json");
        this.appService.sendRequest('POST', context, milkData, headers, null, null).subscribe(
            (response) => {
                console.log(`Cow Available in Auction: ${JSON.stringify(response)}`);
            }, (error) => {
                console.log(`Error in while Getting Auction : ${error}`);
            }
        );
    }

    getMilkAvailableForAuction() {
        return new Observable((observe: Observer<any>) => {
            const context = "/auction/searchMilk";
            const headers = new HttpHeaders();
            headers.set("Content-Type", "application/json");
            this.appService.sendRequest('GET', context, null, headers, null, null).subscribe(
                (response) => {
                    console.log(`Cow Available in Auction: ${JSON.stringify(response)}`);
                    observe.next(response);
                }, (error) => {
                    console.log(`Error in while Getting Auction : ${error}`);
                    observe.error(error);
                }
            );
        });
    }

    purchaseCattle(cattleData) {
        return new Observable((observe: Observer<any>) => {
            const context = "/auction/payment";
            const headers = new HttpHeaders();
            headers.set("Content-Type", "application/json");
            this.appService.sendRequest('POSt', context, cattleData, headers, null, null).subscribe(
                (response) => {
                    console.log(`payment to purchase cow : ${JSON.stringify(response)}`);
                    observe.next(response);
                }, (error) => {
                    console.log(`Error in while purchase cow : ${error}`);
                    observe.error(error);
                }
            );
        });
    }

}