import { Component, OnInit, Inject, ViewChild } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { CattleService } from '../cattle.service';
import { DialogData } from '../delete-cattle/delete-cattle.component';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-sell-cattle',
  templateUrl: './sell-cattle.component.html',
  styleUrls: ['./sell-cattle.component.css']
})
export class SellCattleComponent implements OnInit {

  @ViewChild('sellingForm') sellingForm : NgForm;

  constructor(private dialogRef: MatDialogRef<SellCattleComponent>, @Inject(MAT_DIALOG_DATA) private data: DialogData, private cattleService: CattleService) { }

  ngOnInit() {
  }

  onNoClick() {
    this.dialogRef.close();
  }

  sellCow() {
    this.cattleService.sellCow(this.data.cattleId, this.sellingForm.value);
    this.dialogRef.close();
  }

}
