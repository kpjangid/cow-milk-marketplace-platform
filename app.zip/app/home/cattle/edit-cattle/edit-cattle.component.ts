import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-cattle',
  templateUrl: './edit-cattle.component.html',
  styleUrls: ['./edit-cattle.component.css']
})
export class EditCattleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
