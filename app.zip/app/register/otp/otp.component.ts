import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material';
import { PasscodeComponent } from '../passcode/passcode.component';
import { Router } from '@angular/router';
import { FarmerService, FarmerData } from '../farmer.service';
import { NgForm } from '@angular/forms';
import { timeout } from 'rxjs/operators';
import { SessionService } from '../../shared/services/sessionService';

@Component({
  selector: 'app-otp',
  templateUrl: './otp.component.html',
  styleUrls: ['./otp.component.css']
})
export class OtpComponent implements OnInit {


  @ViewChild('farmerOTPForm') farmerOTPForm: NgForm;

  constructor(private router: Router, private farmerService: FarmerService, private sessionService: SessionService) {
  }

  mobileNumber: any;
  stateList: any;
  passcode: any;

  otp: any = {};

  ngOnInit() {

    this.mobileNumber = this.farmerService.getFarmer().phoneNumber;

    setTimeout(() => {
      this.otp = {
        "1": 2,
        "2": 5,
        "3": 9,
        "4": 2
      };
    }, 1500);

  }

  farmerId: string = "5f3da6346ecbf6363a772e92a63061694216e6b666c6407c1534e82c21d3eeeb1558542904";

  onSubmitOTP() {

    // this.farmerId = this.farmerService.getFarmer().farmerId;

    this.setTestingPass();

    this.farmerService.getFarmerProfileData(this.farmerId).subscribe(
      (response) => {

        console.log(`Farmer Profile = ${JSON.stringify(response)}`);

        const farmerData: FarmerData = {
          farmerId: this.farmerId,
          name: response['name'],
          secretKey: this.farmerId,
          apiKey: this.farmerId,
          passcode: "1234"
        };

        this.farmerService.setFarmerData(farmerData);

        console.log("Setting Farmer Data in Cookie : " + JSON.stringify(this.farmerService.getFarmer()));

        this.sessionService.setFarmerInSession(this.farmerService.getFarmer());

        this.router.navigate(['home', 'landing']);
      }
    );

  }

  setTestingPass(): any {

    const farmerData: FarmerData = {
      farmerId: this.farmerId,
      secretKey: this.farmerId,
      apiKey: this.farmerId,
      passcode: "1234"
    };

    this.farmerService.setFarmerData(farmerData);

    console.log("Setting Farmer Data in Cookie : " + JSON.stringify(this.farmerService.getFarmer()));

    this.sessionService.setFarmerInSession(this.farmerService.getFarmer());

    this.router.navigate(['home', 'landing']);
    

  }

}
