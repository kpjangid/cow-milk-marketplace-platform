import { Injectable } from "@angular/core";
import { AppService } from "../shared/services/appService";
import { HttpHeaders } from "@angular/common/http";
import { Observable, Observer } from "rxjs";

@Injectable({
    providedIn: 'root'
})
export class FarmerService {

    farmerData: FarmerData = {};
    farmerProfileData: FarmerProfileData = {};

    constructor(private appService: AppService) {

    }

    getFarmer() {
        return this.farmerData;
    }

    getFarmerProfileData(farmerId) {

        return new Observable((observer: Observer<FarmerData>) => {

            const context = 'farmer/getFarmerProfile/' + farmerId;

            const headers: HttpHeaders = new HttpHeaders();
            headers.set("Content-Type", "application/json");

            this.appService.sendRequest('GET', context, null, headers, null, null).subscribe(
                (response) => {
                    console.log(`Farmer Data = ${JSON.stringify(response)}`);
                    this.farmerProfileData.state = response['state'];
                    this.farmerProfileData.name = response['name'];
                    this.farmerProfileData.district = response['district'];
                    this.farmerProfileData.dob = response['dob'];
                    this.farmerProfileData.tehsil = response['tehsil'];
                    this.farmerProfileData.cellNumber = response['mobile'];
                    observer.next(response);
                }, (error) => {
                    observer.error(error);
                }
            );
        });

    }

    registerFarmer(farmerJson: any) {

        const context = 'farmer/registerProfile';

        const headers: HttpHeaders = new HttpHeaders();
        headers.set("Content-Type", "application/json");

        this.farmerData.phoneNumber = farmerJson['cellNumber'];

        this.appService.sendRequest('POST', context, farmerJson, headers, null, null).subscribe(
            (response) => {
                console.log(`Farmer Data = ${JSON.stringify(response)}`);
                this.farmerData['farmerId'] = response['farmerId'];
                this.farmerData['secretKey'] = response['farmerId'];
                this.farmerData['privateKey'] = response['farmerId'];
            }
        );
    }

    getFarmerSecretKey() {
        return this.farmerData.secretKey;
    }

    getFarmerAPIKey() {
        return this.farmerData.apiKey;
    }

    setPasscode(passcode) {
        this.farmerData.passcode = passcode;
    }

    setFarmerData(farmerDataTemp: FarmerData) {
        this.farmerData = farmerDataTemp;
    }

    getFarmerProfile() {
        return this.farmerProfileData;
    }

}

export interface FarmerData {
    secretKey?: string;
    apiKey?: string;
    privateKey?: string;
    name?: string;
    farmerId?: string;
    phoneNumber?: string;
    passcode?: string;
}

export interface FarmerProfileData {
    name?: string;
    state?: string;
    district?: string;
    tehsil?: string;
    dob?: string;
    cellNumber?: string;
}