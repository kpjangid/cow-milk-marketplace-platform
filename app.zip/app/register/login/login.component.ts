import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  @ViewChild('farmerLoginForm') farmerLoginForm: NgForm;

  constructor(private router: Router) { }

  ngOnInit() {

  }

  navigate() {
    this.router.navigate(['register', 'farmer']);
  }

  onSubmitLogin() {
    this.router.navigate(['register', 'otp']);
  }

  goToMain(){
    this.router.navigate(['main']);
  }

}
