import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login-doctor',
  templateUrl: './login-doctor.component.html',
  styleUrls: ['./login-doctor.component.css']
})
export class LoginDoctorComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit() {
  }

  navigate() {
    this.router.navigate(['doctor', 'register']);
  }

  onSubmitLogin() {
    this.router.navigate(['doctor', 'otp']);
  }

  goToMain() {
    this.router.navigate(['main']);
  }

}
