import { Component, OnInit } from '@angular/core';
import { DoctorServiceService } from '../../doctor-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-landing-page',
  templateUrl: './landing-page.component.html',
  styleUrls: ['./landing-page.component.css']
})
export class LandingPageComponent implements OnInit {

  cattleList: any = [{
    cowId: "cow-1",
    cowName: "hera",
    healthStatus: "Green",
    age: "10 Years",
    basePrice: "2000",
    farmerId: "343284728934723894723847238",
    imageData: "https://media.istockphoto.com/photos/side-view-of-holstein-cow-5-years-old-standing-picture-id106531788"
  }, {
    cowId: "cow-2",
    cowName: "durga",
    healthStatus: "Green",
    age: "10 Years",
    basePrice: "4000",
    farmerId: "34328472893472389472384928349324",
    imageData: "https://static.independent.co.uk/s3fs-public/thumbnails/image/2018/02/14/16/berkeley-farm-dairy.jpg?w968h681"
  }];

  constructor(private doctorService: DoctorServiceService, private router: Router) { }

  ngOnInit() {
    this.doctorService.getAllCow().subscribe(
      (response) => {
        this.cattleList = response;
      },
      (error) => {
        console.log(`Error : ${error}`);
      }
    );
  }

  navigateToUpdateCow(cowId) {
    this.router.navigate(['doctor', 'cow', 'update', cowId]);
  }

}
