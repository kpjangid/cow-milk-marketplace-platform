import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { DoctorServiceService } from '../../../doctor-service.service';

@Component({
  selector: 'app-update-cow',
  templateUrl: './update-cow.component.html',
  styleUrls: ['./update-cow.component.css']
})
export class UpdateCowComponent implements OnInit {

  @ViewChild('updateCowForm') updateCowForm: NgForm;

  healthCertificate: any;
  healthRecord: any = {};

  constructor(private doctorService: DoctorServiceService) { }

  ngOnInit() {
  }

  onFileSelected() {

    const inputNode: any = document.querySelector('#checkUpTime');
    
    if (typeof (FileReader) !== 'undefined') {

      const reader = new FileReader();
      reader.onload = (e: any) => {
        this.healthCertificate = e.target.result;
      };

      reader.readAsDataURL(inputNode.files[0]);

    }
  }

  updateCow() {
    const updateCowData = this.updateCowForm.value;
    updateCowData['healthCertificate'] = this.healthCertificate;
  }

}
