import { Injectable, OnInit } from "@angular/core";
import { Observable, Observer, Subject } from "rxjs";
import { ActivatedRoute } from "@angular/router";

@Injectable({
    providedIn: 'root'
})
export class UtilityService implements OnInit {

    constructor(private routeParam: ActivatedRoute) { }

    ngOnInit(){

    }

    myRouteObserver = new Subject();

    activateRouter(routerName){
        this.myRouteObserver.next(routerName);
    }
}